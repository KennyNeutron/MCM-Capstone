# NEO-6M_GPS
Arduino driver library for extracting data from a NEO-6M GPS over serial
